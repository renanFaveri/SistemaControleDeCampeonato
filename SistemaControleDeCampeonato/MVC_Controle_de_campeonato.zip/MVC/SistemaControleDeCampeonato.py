from MVC.Controle.controleDeSistema import ControladorDeSistemas

cs = ControladorDeSistemas()
cs.iniciar()