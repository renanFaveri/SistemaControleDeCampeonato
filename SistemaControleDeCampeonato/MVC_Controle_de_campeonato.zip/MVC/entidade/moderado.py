from .rigidez import Rigidez

class Moderado(Rigidez):
    
    def __init__(self, rigidez = 'Moderado'):
        super().__init__(rigidez)
