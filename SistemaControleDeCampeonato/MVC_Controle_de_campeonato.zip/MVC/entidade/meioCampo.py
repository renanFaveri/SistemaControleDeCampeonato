from .posicao import Posicao

class MeioCampista(Posicao):

    def __init__(self, posicao = 'Meio campista'):
        super().__init__(posicao)
        
