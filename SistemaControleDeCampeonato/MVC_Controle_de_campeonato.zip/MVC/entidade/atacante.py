from .posicao import Posicao

class Atacante(Posicao):

    def __init__(self, posicao = 'Atacante'):
        super().__init__(posicao)

