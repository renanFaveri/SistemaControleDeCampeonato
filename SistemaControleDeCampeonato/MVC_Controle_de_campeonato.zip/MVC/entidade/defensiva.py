from .mentalidade import Mentalidade

class Defensiva(Mentalidade):
    
    def __init__(self, mentalidade = 'Defensiva'):
        super().__init__(mentalidade)