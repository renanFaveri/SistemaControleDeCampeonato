from .rigidez import Rigidez

class Severo(Rigidez):
    
    def __init__(self, rigidez = 'Severo'):
        super().__init__(rigidez)