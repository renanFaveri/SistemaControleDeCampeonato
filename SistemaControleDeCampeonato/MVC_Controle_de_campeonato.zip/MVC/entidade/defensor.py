from .posicao import Posicao

class Defensor(Posicao):

    def __init__(self, posicao = 'Defensor'):
        super().__init__(posicao)
