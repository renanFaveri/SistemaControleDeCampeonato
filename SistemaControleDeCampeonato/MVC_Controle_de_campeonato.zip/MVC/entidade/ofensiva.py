from .mentalidade import Mentalidade

class Ofensiva(Mentalidade):
    
    def __init__(self, mentalidade = 'Ofensiva'):
        super().__init__(mentalidade)
