from .posicao import Posicao

class Goleiro(Posicao):

    def __init__(self, posicao = 'Goleiro'):
        super().__init__(posicao)
