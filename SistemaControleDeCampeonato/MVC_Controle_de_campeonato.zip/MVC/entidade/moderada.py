from .mentalidade import Mentalidade

class Moderada(Mentalidade):
    
    def __init__(self, mentalidade = 'Moderada'):
        super().__init__(mentalidade)
        
