from .rigidez import Rigidez

class Brando(Rigidez):
    
    def __init__(self, rigidez = 'Brando'):
        super().__init__(rigidez)
