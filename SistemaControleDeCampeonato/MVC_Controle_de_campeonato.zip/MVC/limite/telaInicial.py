from .tela import Tela

class TelaInicial(Tela):
    
    def __init__(self, controlador):
        super().__init__(controlador, 'Tela inicial')

